#include <msp430g2553.h>
#include "uart.h"
/*
 output arpeggio of notes to a randomized beat pattern
 gate turns off for last 1/4 of duration of note
 beat is fixed at 120
 ToDo: add midi in for clock
 redo rnd() with seed value& algorithm, not just a table

*/
#define 	CLOCKHZ		16000000//sclk
#define		nNotes		24
#define		BUTTON	BIT3
#define BPM 120
#define TICKS_PER_BAR 32 //what
#define BEAT_PER_SECOND BPM/60
#define MAX_MIDI_CHANNELS 16
#define MAX_POLYPHONY 8
unsigned char notes[MAX_POLYPHONY] = {0};
unsigned char note_index;
static const int period = 1280; // period of ccro = period for midi 0-127
 const long cycles_per_second = CLOCKHZ/1280;
  int ticks_per_second = BEAT_PER_SECOND*TICKS_PER_BAR;
unsigned char midi_off =0;
unsigned char curr_note;
static const  unsigned int durProb[] = {1,1,8,3,6,4,6,3};
static const  unsigned int durTable[] = {32,16,8,6,4,3,2,1};
static const  int int_prob[] = {3,1,4,4,4,6,4,6};
static const  int intervals[] = {1,2,3,4,5,7,10,12};

unsigned char midi_fifo[32];
unsigned char midi_fifoIn=0;
unsigned char midi_fifoOut=0;
/*
 * main.c
 */
static const  unsigned int randVals[32] ={ 0xFF, 0x68, 0xF9, 0xB8, 0x10, 0xA1, 0xB6, 0x65, 0xBF, 0x6E, 0x32, 0x2C, 0x95, 0x09, 0xDC, 0x0D, 0xA7, 0x86, 0x00, 0x93, 0xC7, 0x5F, 0x95, 0xA9, 0x5E, 0xFB, 0xC7, 0x22, 0x09, 0xC1, 0xC7, 0xA9,
	};
unsigned int rnd();

char getNextByte();
char opcode;
 char midiByte;
 char newStat =0;
 char nextByte;
 char newByte;
#define MIDI_CHANNEL			0	// MIDI is 1-indexed so setting this to 0 is midi channel 1
//uart rx stuff above
unsigned int getInterval( );
unsigned int getDuration();
void shiftLeft(unsigned char c);
void update_state();
void note_on(unsigned char note);
void note_off(unsigned char note);
unsigned int X = 1;
int noToggle = 0;//for one reading per button press
const int M = 256;
const int a = 65;
const int c = 27;
int ptrRnd = 0;
int offVal = 0;
const unsigned int num_steps = 32;
int index, cycles=0;
int z = 0;
unsigned int pwm2 =1;// for timer A1
 int counter;
const int tableSize = 8;
const unsigned int  pattern[16]= {4,2,4, 8,6,1,2,3,2, 1, 4,2, 1,2,6,8};
char patternPtr=0;
unsigned int cutcounter = 0; //for cutoff attack

float tempo = 120.0;//BPM var for adjustment by midi clock in
unsigned int tempo_counter = 0;
unsigned int last_count = 0;
char clock_on = 0;
volatile int speed_index =8;//for adjusting ticks per clock, but really an effect
float ticks_per_beat = 24;
#define midi_tick 0xf8
#define midi_on 0xFA
#define midi_stop 0xFC
#define midi_continue  0xFB
#define midi_cc 0xB0
#define speed_ctl 12
#define direction_ctl 11
#define interval_ctl 12
#define ornette_ctl  13
#define envelope_ctl 91
void updateControls();
void controlChange();
void update_speed();
void get_ticks_per_second();
void update();
int period_counter= 1;
int go_up = 127;
 char controllerValue, controllerNumber;

//unsigned char midi_note_num, midi_done, midi_note_vel, midi_rec_state, midi_note_chan,  midi_cc_chan=0;
void uart_rx_isr(unsigned char c) {
	uart_putc(c);

}
void main(void) {
  	DCOCTL = CALDCO_16MHZ;
	BCSCTL1 = CALBC1_16MHZ;
	BCSCTL2 |= DIVS_1;						// SMCLK = MCLK/2 =8MHZ

	WDTCTL = WDTPW + WDTHOLD;               // Stop WDT

	P1DIR |= BIT7 | BIT6 | BIT5 | BIT4 | BIT2 |  BIT0; // Direction
	 P1SEL |= BIT6 | BIT4 | BIT1;                 // Select Timer A output, SMCLK output, UART Rx
	 			  P1SEL2 |= BIT1;
	 P1REN |=  BIT2 + BIT5;
  P1OUT |= BIT2;//BIT2 + BIT6;
  P2DIR |= BIT0 + BIT2 + BIT3;
  P2OUT |= BIT2;
  P2SEL |= BIT2;
  P2REN |= BIT2;
	TACCR0 = period;         // Setup Timer A for 32768 Hz period
	TACCR1  =  TA0CCR0/2;                      // Setup Timer A compare to midpoint
	    TACCTL1 = OUTMOD_7;                        // Setup Timer A reset/set output mode
	    TACTL = TASSEL_2 | MC_1;                   // Timer A config: SMCLK, count up
	   TACCTL0 |= CCIE;                           // Enable period interrupt
	   //P2DIR =  BIT2;
	   	TA1CCR0 = period  ;         // Setup Timer A for 32768 Hz period
	   	TA1CCR1  = TA1CCR0/2;// TA1CCR0/2;                      // Setup Timer A compare to midpoint
	   	    TA1CCTL1 = OUTMOD_7;                        // Setup Timer A reset/set output mode
	   	    TA1CTL = TASSEL_2 | MC_1;                   // Timer A config: SMCLK, count up
	   	   TA1CCTL0 |= CCIE;                           // Enable period interrupt

	   //USCI init
	   	UCA0CTL1 |= UCSWRST;
	  // UCB0CTL1 |= UCSWRST;

	   //UCA0CTL0 = UCMODE_3;
	   UCA0CTL1 = UCSSEL_2 + UCSWRST;

	   UCA0BR0 = 8;                            //  DIVIDES SMCLK  = 31250  = MIDI SPEC w/UCOS16 oversample
	     	UCA0BR1 = 0;                              //
	     	UCA0MCTL |= UCOS16;                        // 16x oversample
	     	P1IE |= BUTTON; // P1.3 interrupt enabled
	   //IE2 |= UCA0RXIE;                          // Enable USCI_A0 RX interrupt

	   uart_init();

	   		// register ISR called when data was received
	   	    uart_set_rx_isr_ptr(uart_rx_isr);

	   	 __bis_SR_register(GIE);                                        //
	   // _enable_interrupts();                       // Enable interrupts
	   	get_ticks_per_second();
	   	update();                                              //
	   while(1){
		   if(period_counter)
			   update();
	   	  opcode = getNextByte();

	     	if((opcode == midi_tick)){
	     			//if(clock_on){

	     		update_speed();

	     			//}
	     	}
	     	//if(period_counter)

if(opcode == midi_on){
	clock_on = 0xFF;// turn on clock
	last_count = tempo_counter;
}
if(opcode == midi_stop){
	clock_on = 0;//no longer getting clock. go to default tempo
	tempo = 120.0;
	get_ticks_per_second();// avoid 0 tempo on next start

}
 if(opcode == (0xB0 | MIDI_CHANNEL )){

  		controlChange();
}
	   }
}
void controlChange(){
	do{
		controllerNumber = getNextByte();
		if(controllerNumber & 0x80){
			newStat = 1;
			break;
		}
		controllerValue = getNextByte();
		if(controllerValue & 0x80){
			newStat = 1;
			break;
		}
		updateControls();
	}while(1);
}

void updateControls(){
	if(controllerNumber ==speed_ctl){//
		if(controllerValue)
			speed_index = 4 * ((controllerValue>>6) +1);// scale to 4-16
		//speed_index +=1;//make non-zero
		update_speed();

	}
	else if(controllerNumber == direction_ctl){//
		if(controllerValue){
			go_up=255-controllerValue;
		}

	}

	else if(controllerNumber == interval_ctl)
	{

		;}
	if(controllerNumber == ornette_ctl)
		{

			;}
}
char getNextByte(){

	if(newStat)
		{
		newStat = 0;
			return nextByte;
		}
	else
	{
		do{

			;//P1OUT &= ~BIT0;

		while(!newByte){
		}

		nextByte =  uart_getByte();
}while((nextByte == 0xFE) || (nextByte == 0xFF));
		//P1OUT |= BIT0;


	return nextByte;
}
}
void update(){
	 int cycles_per_tick = cycles_per_second/ticks_per_second;
		int elapsed = period_counter;
		period_counter= 0;
		P1OUT |= BIT5;

		  if(counter>0){
	    	counter-=elapsed;//-=elapsed;

	    if(counter < offVal)
	    	P1OUT &= ~BIT5;// turn off for last quarter of duration
	    }
	    else {
	    	counter=cycles_per_tick*getDuration();
	    	if (patternPtr>=16)
	    		patternPtr = 0;
	    	if(rnd()<24)
	    		offVal = counter;
	    	else
	    		offVal = counter>>2;
	    if(rnd()>go_up)
	    {
	    	int temp;
	    	temp=getInterval()*10;
	    if (temp<z)
	    	z=z-temp;
	    else
	    	z=temp-z;
	    	}
	   else
	    	z=z + (getInterval()*10);

	    	if(z>= period)
	    		z-=period;
	    	if(z <0)
	    		z =period+z;

	    }


}
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A0 (void){
	tempo_counter++;
	period_counter++;



	   TA0CCR0 = period;
    TA0CCR1 = z ;
    pwm2 = z;



}
#pragma vector=TIMER1_A0_VECTOR
__interrupt void Timer1_A0 (void){
	TA1CCR0 = period;
	TA1CCR1 = z;
}
unsigned int rnd(){
	if(ptrRnd>=32)
		ptrRnd = 0;
	//X = randVals[ptrRnd++];//
	X=(a * X + c) % M ;// 0 to 255
		 return X;
}
unsigned int getInterval( ){

	unsigned int random = 0;
	unsigned int counter = 0;//lastIndex;
	unsigned int sum = 0; //tally of probabilty vals
	random = rnd();

	while(sum<=random){

		sum += int_prob[counter++ ];
		if (counter>= tableSize)
			counter = 0;
	}
	//P1OUT ^= BIT0;
	return intervals[counter];
}
unsigned int getDuration()
{

	unsigned int random =0;
  unsigned int counter = 0;
	unsigned int sum = 0;
	random = rnd()  ;

	while ( sum <   random){
		sum = sum+ durProb[counter++];

		if (counter>= 8)
		counter = 0;
		//P1OUT ^= BIT0;
}


//add up to random probability, then get the actual duration
	return durTable[counter];//it wont execute this command!?!

}

// Port 1 interrupt service routine
	#pragma vector=PORT1_VECTOR
	__interrupt void Port_1(void)
	{

	if(!noToggle){
		X= TA0R &0xFF;// read timer value and put lowest 8 bits in X
		X += TA0R &0xFF;
		X = (X>>1) + 1;
		noToggle = 1;
	}
	else noToggle = 0;//keep it from toggling
	///else like =0;//toggle
	P1IFG &= ~BUTTON; // P1.3 IFG cleared
	P1IES ^= BUTTON; // toggle the interrupt edge,
	P1REN |= BUTTON + BIT6;// ren button  // the interrupt vector will be called
	// when P1.3 goes from HitoLow as well as
	// LowtoHigh
	}// how to get ccr0 counter it is TAR or TA0R. "results can be unpredictable" according to manual, thats how I like it.
void update_speed(){
	tempo = 60*(((float)ticks_per_beat/speed_index)*( (float)(period)/tempo_counter));// sixty times ticks per beat over periods elapsed time period over scaler, 24 ticks per quarter note -->BPM
		     		get_ticks_per_second();
		     		last_count = tempo_counter;
		     		tempo_counter = 0;
		     		P1OUT ^= BIT0;
}
void get_ticks_per_second(){
	ticks_per_second = tempo/60*TICKS_PER_BAR;//
}
